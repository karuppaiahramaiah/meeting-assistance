// <copyright file="store.js" company="Microsoft">
// Copyright (c) Microsoft. All rights reserved.
// </copyright>

const MemoryStorage = require('memorystorage');
const store = new MemoryStorage('details-tab-app');
module.exports = store